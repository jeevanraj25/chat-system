<?php
  $hostname = "localhost";
  $username = "u413079379_root";
  $password = "Aashrith@1";
  $dbname = "u413079379_chatapp";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
